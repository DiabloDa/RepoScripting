﻿using System.Linq.Expressions;
using System.Security.Cryptography.X509Certificates;

namespace Talller_1_Scrpting_ejercicio_2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Ciclo();
            

        }
        public static void Ciclo()
        {
            int tamaño = 0;
            Console.WriteLine("Por favor ingrese el número hasta que desea sumar");
            tamaño = Convert.ToInt32(Console.ReadLine());
            int suma = 0;
            int contador = 0;
            int numero = 1;
            
            do
            {

                suma += numero;
                contador++;
                numero += 2;

            } while (contador < tamaño);

            Console.WriteLine($"La suma de los primeros {tamaño} números impares es: {suma}");
        }
    }
}
