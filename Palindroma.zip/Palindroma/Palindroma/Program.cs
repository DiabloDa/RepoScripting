﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Palindroma
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Menu();
        }

        public static void Menu()
        {
            int i = 0;
            Console.WriteLine("Pon una palabra palindroma");
            string palabra = Console.ReadLine();
            i = Verificacion(i, palabra);
            if(i == 1)
            {
                Console.WriteLine("La palabra es palindroma");
            }
            else
            {
                Console.WriteLine("No es palindroma");
            }

        }

        public static int Verificacion(int i, string cadena)
        {
            string palindroma = new string(cadena.ToLower().Reverse().ToArray());

            if(cadena.ToLower() == palindroma)
            {
                i = 1;
            }
            else
            {
                i = 0;
            }
            
            return i;
        }

    }
}
