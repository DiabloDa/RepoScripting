﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PuntoCaracteres
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Menu();
        }
        public static void Menu()
        {
            string num;
            int tamaño;

            Console.WriteLine("Escriba números positivos");
            num = Console.ReadLine();
            tamaño = num.Length;

            int[] numeros = new int[tamaño];

            for (int i = 0; i < tamaño; i++)
            {
                try
                {
                    numeros[i] = int.Parse(num[i].ToString());
                }
                catch
                {
                    Console.WriteLine("Hay un entero");
                }               
            }

            Console.WriteLine("Los números en el array son:");

            foreach (int n in numeros)
            {
                Console.WriteLine(n);
            }
        }
    }
}
