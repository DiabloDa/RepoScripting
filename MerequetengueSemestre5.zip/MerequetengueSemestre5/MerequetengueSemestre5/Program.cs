﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace MerequetengueSemestre5
{
    internal class Program
    {
        public static int n, m = 0;
        static void Main(string[] args)
        {
            Menu();

        }

        public static void Menu()
        {
            
            Console.WriteLine("Ingrese el tamaño de la matriz");

            try
            {
                n = int.Parse(Console.ReadLine());
                m = int.Parse(Console.ReadLine());
            }

            catch
            {
                Console.WriteLine("Nel, vuelvalo a intentar");
                Menu();
            }

            int[,] matriz = new int[n, m];

            Random rand = new Random();



            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    int numeroAleatorio = rand.Next(-9, 3);
                    matriz[i, j] = numeroAleatorio;
                }
            }

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    Console.Write("|" + matriz[i, j] + "|");
                }
                Console.WriteLine("");
            }

            Console.WriteLine("Convirtiendo a positivo...");
            Thread.Sleep(1000);
            NumerosPos(matriz);

        }

        public static void NumerosPos(int[,] matriz)
        {
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    if (matriz[i,j] < 0)
                    {
                        matriz[i, j] = matriz[i, j] * -1; 
                    }
                }
            }

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    Console.Write("|" + matriz[i, j] + "|");
                }
                Console.WriteLine("");
            }
        }



    }
}
